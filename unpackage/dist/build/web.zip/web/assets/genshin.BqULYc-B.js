const s="/assets/genshin-BSELyNhl.jpg";export{s as _};
