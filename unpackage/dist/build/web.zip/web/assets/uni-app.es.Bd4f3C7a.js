import{a9 as a,aa as s,U as o,ab as r,ac as t}from"./index-CbEuBPGN.js";function n(a,s){return"string"==typeof a?s:a}const e=r=>(t,n=o())=>{!a&&s(r,t,n)},i=e(r),c=e(t);export{i as a,c as o,n as r};
